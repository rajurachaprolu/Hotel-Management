public class Holder {
    DoubleRoom luxury_doubleroom[] = new DoubleRoom[10];
    DoubleRoom deluxe_doubleroom[] = new DoubleRoom[20];
    SingleRoom luxury_singleroom[] = new SingleRoom[10];
    SingleRoom deluxe_singleroom[] = new SingleRoom[20];
}